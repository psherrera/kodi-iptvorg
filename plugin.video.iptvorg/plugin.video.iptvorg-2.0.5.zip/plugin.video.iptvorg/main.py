# -*- coding: utf-8 -*-
import sys

if sys.argv and sys.argv[0].startswith('plugin://'):
    # Invoked as a plugin (directory navigation / actions)
    from resources.lib import plugin
    plugin.run()
else:
    # Invoked as a script (RunScript) -> open the Netflix-style window
    from resources.lib import gui
    gui.open_home()
