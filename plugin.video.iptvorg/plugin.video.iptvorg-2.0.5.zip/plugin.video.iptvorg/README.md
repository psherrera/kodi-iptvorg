# IPTV-org para Kodi (plugin.video.iptvorg) — v2.0.1

Addon de video para Kodi 19+ que navega las listas públicas de
[iptv-org/iptv](https://github.com/iptv-org/iptv), con una interfaz estilo Netflix.

## Interfaz estilo Netflix
Al abrir el addon se lanza una ventana propia (WindowXML) con:
- Header con logo y navegación superior: Inicio · Categorías · Países · Idiomas · Mis listas · Mi lista · Buscar.
- Hero grande con el canal enfocado (logo, grupo, calidad).
- Fila horizontal de tarjetas con los logos de cada canal.
- Carga en segundo plano (spinner) para no congelar la UI.

Se puede desactivar en Ajustes → *Abrir la home estilo Netflix por defecto*,
y entonces se usa el modo clásico de carpetas de Kodi.

## Mis listas
Panel propio para cargar **tus** listas:
- **URL M3U**: pegás la dirección de tu lista .m3u/.m3u8.
- **Cuenta Xtream**: servidor + usuario + contraseña tuyos; el addon arma la URL `get.php` con `type=m3u_plus`.

Se agregan desde el panel *Mis listas* (tile "Agregar lista") o desde Ajustes → *Mis listas*.
Las credenciales quedan solo en tu perfil de Kodi (`sources.json`); el addon no trae listas de terceros.

## Instalación
1. Kodi → Ajustes → Sistema → Add-ons → activar *Orígenes desconocidos*.
2. Add-ons → *Instalar desde un archivo .zip* → `plugin.video.iptvorg-2.0.1.zip`.

## Ajustes
Home Netflix por defecto, duración de caché, canales por página, orden alfabético,
mostrar provincias, InputStream Adaptive para HLS, borrar caché y gestión de Mis listas.

## Notas
- El addon no aloja contenido; los enlaces de iptv-org vienen de emisoras públicas y pueden caerse.
- Respeta las cabeceras `http-referrer` / `http-user-agent` de las listas.
- La ventana XML está hecha para 1080i y usa fuentes estándar de Estuary.
