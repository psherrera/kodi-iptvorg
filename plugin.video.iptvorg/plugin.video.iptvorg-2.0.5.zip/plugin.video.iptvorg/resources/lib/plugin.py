# -*- coding: utf-8 -*-
"""Classic directory mode + shared actions (sources, favourites, playback).

The Netflix-style window (gui.py) reuses the same action URLs for playback
and source management, so everything funnels through run()."""
import json
import sys
import uuid
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import common as C
from resources.lib import m3u

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
PLUGIN_URL = sys.argv[0] if sys.argv else 'plugin://%s/' % C.ADDON_ID


def build_url(**params):
    return PLUGIN_URL + '?' + urlencode(params)


# --------------------------------------------------------------------------
# Directory helpers
# --------------------------------------------------------------------------

def add_folder(label, url, icon=None, plot='', fanart=None):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': icon or C.ADDON_ICON, 'thumb': icon or C.ADDON_ICON,
               'fanart': fanart or C.ADDON_FANART})
    if plot and hasattr(li, 'getVideoInfoTag'):
        li.getVideoInfoTag().setPlot(plot)
    elif plot:
        li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def end_list(content='videos', sort=False, cache=True):
    xbmcplugin.setContent(HANDLE, content)
    if sort:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def channel_label(ch):
    if not ch['tags']:
        return ch['title']
    return '%s [COLOR grey]%s[/COLOR]' % (ch['title'], ' '.join(ch['tags']))


def add_channel(ch, fav_urls, in_favs=False):
    li = xbmcgui.ListItem(label=channel_label(ch))
    logo = ch.get('logo') or C.ADDON_ICON
    li.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': C.ADDON_FANART})
    plot = []
    if ch.get('group'):
        plot.append(ch['group'].replace(';', ', '))
    if ch.get('tags'):
        plot.append(' '.join(ch['tags']))
    if hasattr(li, 'getVideoInfoTag'):
        tag = li.getVideoInfoTag()
        tag.setTitle(ch['title'])
        tag.setPlot('\n'.join(plot))
        tag.setMediaType('video')
        if ch.get('group'):
            tag.setGenres(ch['group'].split(';'))
    else:
        li.setInfo('video', {'title': ch['title'], 'plot': '\n'.join(plot),
                             'genre': ch.get('group', '').replace(';', ', ')})
    li.setProperty('IsPlayable', 'true')

    payload = json.dumps(ch, ensure_ascii=False)
    if in_favs or ch['url'] in fav_urls:
        cm = [(C.T(30009), 'RunPlugin(%s)' % build_url(action='fav_remove', u=ch['url']))]
    else:
        cm = [(C.T(30008), 'RunPlugin(%s)' % build_url(action='fav_add', ch=payload))]
    li.addContextMenuItems(cm)

    url = build_url(action='play', ch=payload)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


def list_channels(channels, page, next_params):
    per_page = max(20, C.setting_int('per_page', 200))
    fav_urls = {f['url'] for f in C.load_favs()}
    start = page * per_page
    for ch in channels[start:start + per_page]:
        add_channel(ch, fav_urls)
    if start + per_page < len(channels):
        total_pages = (len(channels) + per_page - 1) // per_page
        np = dict(next_params, page=page + 1)
        add_folder('[B]%s (%d/%d) >>[/B]' % (C.T(30007), page + 2, total_pages),
                   build_url(**np))
    end_list('videos', cache=False)


# --------------------------------------------------------------------------
# Views
# --------------------------------------------------------------------------

def view_root():
    if C.setting_bool('netflix_default'):
        # Launch the window as a SEPARATE script invocation. A plugin:// call
        # must return quickly; blocking it with a modal window makes Kodi kill
        # the script after 5s ("script didn't stop in 5 seconds").
        xbmc.executebuiltin('RunScript(%s)' % C.ADDON_ID)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    add_folder('[B]%s[/B]' % C.T(30020), build_url(action='sources'), icon=C.media('nav_mylist.png'))
    add_folder(C.T(30006), build_url(action='favourites'), icon=C.media('nav_mylist.png'))
    add_folder(C.T(30001), build_url(action='countries'), icon=C.media('nav_country.png'))
    add_folder(C.T(30002), build_url(action='list_group', kind='categories'))
    add_folder(C.T(30003), build_url(action='list_group', kind='languages'))
    add_folder(C.T(30004), build_url(action='list_group', kind='regions'))
    add_folder(C.T(30000), build_url(action='playlist', u=C.INDEX_URL))
    add_folder(C.T(30005), build_url(action='search'), icon=C.media('nav_search.png'))
    end_list('files')


def view_countries():
    data = C.get_index()
    for c in data['countries']:
        code = c['code']
        icon = C.ADDON_ICON if code in ('int', 'undefined') else \
            C.FLAG_URL.format('gb' if code == 'uk' else code)
        if c.get('subdivisions') and C.setting_bool('show_subdivisions'):
            url = build_url(action='country', code=code)
        else:
            url = build_url(action='playlist', u=c['url'])
        add_folder(c['name'], url, icon=icon)
    end_list('files', sort=True)


def view_country(code):
    data = C.get_index()
    country = next((c for c in data['countries'] if c['code'] == code), None)
    if not country:
        end_list('files')
        return
    icon = C.FLAG_URL.format('gb' if code == 'uk' else code)
    add_folder('[B]%s - %s[/B]' % (C.T(30010), country['name']),
               build_url(action='playlist', u=country['url']), icon=icon)
    for sub in country['subdivisions']:
        if sub.get('cities'):
            url = build_url(action='subdivision', code=code, sub=sub['code'])
        else:
            url = build_url(action='playlist', u=sub['url'])
        add_folder(sub['name'], url, icon=icon)
    end_list('files')


def view_subdivision(code, sub_code):
    data = C.get_index()
    country = next((c for c in data['countries'] if c['code'] == code), None)
    sub = next((s for s in country['subdivisions'] if s['code'] == sub_code), None) if country else None
    if not sub:
        end_list('files')
        return
    icon = C.FLAG_URL.format('gb' if code == 'uk' else code)
    add_folder('[B]%s - %s[/B]' % (C.T(30010), sub['name']),
               build_url(action='playlist', u=sub['url']), icon=icon)
    for city in sub['cities']:
        add_folder(city['name'], build_url(action='playlist', u=city['url']), icon=icon)
    end_list('files')


def view_group(kind):
    data = C.get_index()
    for entry in data.get(kind, []):
        label = entry['name']
        if entry.get('count'):
            label = '%s [COLOR grey](%d)[/COLOR]' % (label, entry['count'])
        add_folder(label, build_url(action='playlist', u=entry['url']))
    end_list('files')


def view_playlist(url, page):
    channels = C.load_channels(url)
    if channels is None:
        C.notify(C.T(30014), ms=4000)
        end_list()
        return
    list_channels(channels, page, {'action': 'playlist', 'u': url})


def view_search(query=None, page=0):
    if query is None:
        query = xbmcgui.Dialog().input(C.T(30016))
        if not query:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
    channels = C.load_channels(C.INDEX_URL) or []
    terms = m3u.normalize(query).split()
    results = [c for c in channels
               if all(t in m3u.normalize(c['name'] + ' ' + c.get('group', '')) for t in terms)]
    if not results:
        C.notify(C.T(30015), ms=3000)
    list_channels(results, page, {'action': 'search', 'q': query})


def view_favourites():
    for ch in C.load_favs():
        add_channel(ch, set(), in_favs=True)
    end_list('videos', cache=False)


def view_sources():
    add_folder('[B]+ %s[/B]' % C.T(30021), build_url(action='add_source'),
               icon=C.media('nav_add.png'), plot=C.T(30022))
    for src in C.load_sources():
        label = src['name']
        li_url = build_url(action='playlist', u='src:' + src['id'])
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': C.media('nav_mylist.png'), 'thumb': C.media('nav_mylist.png'),
                   'fanart': C.ADDON_FANART})
        li.addContextMenuItems([
            (C.T(30024), 'RunPlugin(%s)' % build_url(action='del_source', id=src['id']))])
        xbmcplugin.addDirectoryItem(HANDLE, li_url, li, isFolder=True)
    end_list('files')


# --------------------------------------------------------------------------
# Source management (used by classic mode and the Netflix window)
# --------------------------------------------------------------------------

def add_source():
    dlg = xbmcgui.Dialog()
    choice = dlg.select(C.T(30021), [C.T(30025), C.T(30026)])  # M3U URL / Xtream
    if choice < 0:
        return
    name = dlg.input(C.T(30027))
    if not name:
        return
    sources = C.load_sources()
    if choice == 0:
        url = dlg.input(C.T(30028))
        if not url:
            return
        sources.append({'id': uuid.uuid4().hex[:8], 'type': 'm3u', 'name': name, 'url': url})
    else:
        server = dlg.input(C.T(30029))        # http://host:port
        if not server:
            return
        user = dlg.input(C.T(30037))
        if not user:
            return
        password = dlg.input(C.T(30038), option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if password is None:
            return
        sources.append({'id': uuid.uuid4().hex[:8], 'type': 'xtream', 'name': name,
                        'server': server, 'user': user, 'password': password})
    C.save_sources(sources)
    C.notify(C.T(30023))
    xbmc.executebuiltin('Container.Refresh')


def del_source(source_id):
    if not xbmcgui.Dialog().yesno(C.ADDON_NAME, C.T(30039)):
        return
    C.save_sources([s for s in C.load_sources() if s['id'] != source_id])
    xbmc.executebuiltin('Container.Refresh')


# --------------------------------------------------------------------------
# Actions
# --------------------------------------------------------------------------

def play(ch):
    xbmcplugin.setResolvedUrl(HANDLE, True, C.make_play_item(ch))


def run():
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    page = int(params.get('page', 0))

    if action is None:
        view_root()
    elif action == 'countries':
        view_countries()
    elif action == 'country':
        view_country(params['code'])
    elif action == 'subdivision':
        view_subdivision(params['code'], params['sub'])
    elif action == 'list_group':
        view_group(params['kind'])
    elif action == 'playlist':
        view_playlist(params['u'], page)
    elif action == 'search':
        view_search(params.get('q'), page)
    elif action == 'favourites':
        view_favourites()
    elif action == 'sources':
        view_sources()
    elif action == 'add_source':
        add_source()
    elif action == 'del_source':
        del_source(params['id'])
    elif action == 'play':
        play(json.loads(params['ch']))
    elif action == 'fav_add':
        if C.fav_add(json.loads(params['ch'])):
            C.notify(C.T(30018))
    elif action == 'fav_remove':
        C.fav_remove(params['u'])
        C.notify(C.T(30019))
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'clear_cache':
        C.clear_cache()
        C.notify(C.T(30013))
    else:
        view_root()
