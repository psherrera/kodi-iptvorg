# -*- coding: utf-8 -*-
"""Shared logic for IPTV-org: settings, network cache, index, playlists,
favourites, user sources and playback. No window code here, so it can be
unit-tested outside Kodi."""
import hashlib
import json
import os
import sys
import time
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import m3u

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_FANART = ADDON.getAddonInfo('fanart')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_DIR = os.path.join(PROFILE, 'cache')
FAV_FILE = os.path.join(PROFILE, 'favourites.json')
SOURCES_FILE = os.path.join(PROFILE, 'sources.json')
MEDIA = os.path.join(ADDON_PATH, 'resources', 'skins', 'default', 'media')

BASE = 'https://iptv-org.github.io/iptv/'
INDEX_URL = BASE + 'index.m3u'
PLAYLISTS_MD = 'https://raw.githubusercontent.com/iptv-org/iptv/master/PLAYLISTS.md'
API = 'https://iptv-org.github.io/api/'
FLAG_URL = 'https://flagcdn.com/w320/{}.png'
UA = 'Mozilla/5.0 (Kodi; plugin.video.iptvorg) AppleWebKit/537.36'

# Curated tiles for the Netflix-style home: (label string id, category file, art).
HOME_ROWS = [
    (30030, BASE + 'categories/news.m3u', 'cat_news.png'),
    (30031, BASE + 'categories/sports.m3u', 'cat_sports.png'),
    (30032, BASE + 'categories/movies.m3u', 'cat_movies.png'),
    (30033, BASE + 'categories/music.m3u', 'cat_music.png'),
    (30034, BASE + 'categories/kids.m3u', 'cat_kids.png'),
    (30035, BASE + 'categories/documentary.m3u', 'cat_docu.png'),
    (30036, BASE + 'categories/entertainment.m3u', 'cat_ent.png'),
]


def T(string_id):
    return ADDON.getLocalizedString(string_id)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def setting_int(key, default):
    try:
        return int(ADDON.getSetting(key) or default)
    except ValueError:
        return default


def setting_bool(key):
    return ADDON.getSetting(key) == 'true'


def media(name):
    return os.path.join(MEDIA, name)


def notify(msg, icon=None, ms=2500):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon or ADDON_ICON, ms)


# --------------------------------------------------------------------------
# Network + cache
# --------------------------------------------------------------------------

def fetch(url, ttl_hours=None):
    if ttl_hours is None:
        ttl_hours = setting_int('cache_hours', 12)
    if not os.path.isdir(CACHE_DIR):
        os.makedirs(CACHE_DIR)
    path = os.path.join(CACHE_DIR, hashlib.md5(url.encode('utf-8')).hexdigest())
    fresh = os.path.exists(path) and (time.time() - os.path.getmtime(path)) < ttl_hours * 3600
    if fresh:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    try:
        req = Request(url, headers={'User-Agent': UA})
        with urlopen(req, timeout=30) as resp:
            data = resp.read().decode('utf-8', 'replace')
        with open(path, 'w', encoding='utf-8') as f:
            f.write(data)
        return data
    except Exception as exc:
        log('Error downloading %s: %s' % (url, exc), xbmc.LOGWARNING)
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        return None


def clear_cache():
    if os.path.isdir(CACHE_DIR):
        for name in os.listdir(CACHE_DIR):
            try:
                os.remove(os.path.join(CACHE_DIR, name))
            except OSError:
                pass


# --------------------------------------------------------------------------
# Index + playlists
# --------------------------------------------------------------------------

def get_index():
    text = fetch(PLAYLISTS_MD)
    data = m3u.parse_playlists_md(text) if text else None
    if data and data['countries'] and data['categories']:
        return data
    log('PLAYLISTS.md unavailable, falling back to API', xbmc.LOGWARNING)
    data = {'categories': [], 'languages': [], 'regions': [], 'countries': []}
    try:
        for c in json.loads(fetch(API + 'categories.json') or '[]'):
            data['categories'].append({'name': c['name'], 'code': c['id'],
                                       'url': BASE + 'categories/%s.m3u' % c['id']})
        for l in json.loads(fetch(API + 'languages.json') or '[]'):
            data['languages'].append({'name': l['name'], 'code': l['code'],
                                      'url': BASE + 'languages/%s.m3u' % l['code']})
        for r in json.loads(fetch(API + 'regions.json') or '[]'):
            code = r['code'].lower()
            data['regions'].append({'name': r['name'], 'code': code,
                                    'url': BASE + 'regions/%s.m3u' % code})
        for c in json.loads(fetch(API + 'countries.json') or '[]'):
            code = c['code'].lower()
            file_code = 'uk' if code == 'gb' else code
            data['countries'].append({'name': c['name'], 'code': file_code,
                                      'url': BASE + 'countries/%s.m3u' % file_code,
                                      'subdivisions': []})
    except Exception as exc:
        log('API fallback failed: %s' % exc, xbmc.LOGERROR)
    return data


def load_channels(url):
    """Return channel dicts for a playlist URL or a user source id (src:<id>)."""
    if url.startswith('src:'):
        return load_source_channels(url[4:])
    text = fetch(url)
    if text is None:
        return None
    channels = m3u.parse_m3u(text)
    if setting_bool('sort_alpha'):
        channels.sort(key=lambda c: m3u.normalize(c['title']))
    return channels


# --------------------------------------------------------------------------
# Favourites ("Mi lista")
# --------------------------------------------------------------------------

def load_favs():
    try:
        with open(FAV_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []


def save_favs(favs):
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    with open(FAV_FILE, 'w', encoding='utf-8') as f:
        json.dump(favs, f, ensure_ascii=False, indent=1)


def is_fav(url):
    return any(f['url'] == url for f in load_favs())


def fav_add(ch):
    favs = load_favs()
    if not any(f['url'] == ch['url'] for f in favs):
        favs.append(ch)
        save_favs(favs)
        return True
    return False


def fav_remove(url):
    favs = [f for f in load_favs() if f['url'] != url]
    save_favs(favs)


def fav_toggle(ch):
    if is_fav(ch['url']):
        fav_remove(ch['url'])
        return False
    fav_add(ch)
    return True


# --------------------------------------------------------------------------
# User sources (own M3U URL or own Xtream account)
# --------------------------------------------------------------------------

def load_sources():
    try:
        with open(SOURCES_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return []


def save_sources(sources):
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    with open(SOURCES_FILE, 'w', encoding='utf-8') as f:
        json.dump(sources, f, ensure_ascii=False, indent=1)


def xtream_m3u_url(server, user, password):
    server = server.rstrip('/')
    if not server.startswith('http'):
        server = 'http://' + server
    return '%s/get.php?username=%s&password=%s&type=m3u_plus&output=ts' % (
        server, quote(user), quote(password))


def load_source_channels(source_id):
    src = next((s for s in load_sources() if s['id'] == source_id), None)
    if not src:
        return None
    if src['type'] == 'xtream':
        url = xtream_m3u_url(src['server'], src['user'], src['password'])
    else:
        url = src['url']
    text = fetch(url, ttl_hours=setting_int('cache_hours', 12))
    if text is None:
        return None
    channels = m3u.parse_m3u(text)
    if setting_bool('sort_alpha'):
        channels.sort(key=lambda c: m3u.normalize(c['title']))
    return channels


# --------------------------------------------------------------------------
# Playback
# --------------------------------------------------------------------------

def make_play_item(ch):
    """Build a playable xbmcgui.ListItem with headers / InputStream Adaptive."""
    url = ch['url']
    headers = ch.get('headers', {}) or {}
    title = ch.get('title', '')
    logo = ch.get('logo', '') or ADDON_ICON
    li = xbmcgui.ListItem(label=title, path=url)
    li.setArt({'icon': logo, 'thumb': logo})
    if hasattr(li, 'getVideoInfoTag'):
        li.getVideoInfoTag().setTitle(title)
    else:
        li.setInfo('video', {'title': title})
    header_str = urlencode(headers, quote_via=quote) if headers else ''

    use_isa = (setting_bool('use_isa') and '.m3u8' in url.lower()
               and xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'))
    if use_isa:
        li.setProperty('inputstream', 'inputstream.adaptive')
        try:
            kodi_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0] or 0)
        except ValueError:
            kodi_major = 0
        if kodi_major < 21:
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        if header_str:
            li.setProperty('inputstream.adaptive.manifest_headers', header_str)
            li.setProperty('inputstream.adaptive.stream_headers', header_str)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
    elif header_str:
        li.setPath(url + '|' + header_str)
    return li
