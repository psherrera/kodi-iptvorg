# -*- coding: utf-8 -*-
"""Parsers for iptv-org playlists (M3U) and the PLAYLISTS.md index.

Pure Python, no Kodi imports, so it can be tested outside Kodi.
"""
import re
import unicodedata

_ATTR_RE = re.compile(r'([\w-]+)="([^"]*)"')
_TAG_RE = re.compile(r'\s*(\[[^\]]+\]|\(\d{3,4}[pi]\))')
_URL_RE = re.compile(r'<?(https?://iptv-org\.github\.io/iptv/([a-z]+)/([^>`\s]+)\.m3u)>?')


def normalize(text):
    """Lower-case and strip accents, for search."""
    text = unicodedata.normalize('NFKD', text or '')
    return ''.join(c for c in text if not unicodedata.combining(c)).lower()


def parse_m3u(text):
    """Return a list of channel dicts from an M3U playlist.

    Each dict has: name, title (name without tags), tags, url, logo,
    group, tvg_id, headers (dict with User-Agent / Referer if present).
    """
    channels = []
    current = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith('#EXTINF'):
            head, _, name = line.partition(',')
            attrs = dict(_ATTR_RE.findall(head))
            name = name.strip() or attrs.get('tvg-name', '')
            headers = {}
            if attrs.get('http-user-agent'):
                headers['User-Agent'] = attrs['http-user-agent']
            if attrs.get('http-referrer'):
                headers['Referer'] = attrs['http-referrer']
            tags = [t.strip() for t in _TAG_RE.findall(name)]
            current = {
                'name': name,
                'title': _TAG_RE.sub('', name).strip() or name,
                'tags': tags,
                'logo': attrs.get('tvg-logo', ''),
                'group': attrs.get('group-title', ''),
                'tvg_id': attrs.get('tvg-id', ''),
                'headers': headers,
            }
        elif line.startswith('#EXTVLCOPT:') and current is not None:
            opt = line[len('#EXTVLCOPT:'):]
            key, _, value = opt.partition('=')
            key = key.strip().lower()
            if key == 'http-user-agent':
                current['headers']['User-Agent'] = value.strip()
            elif key == 'http-referrer':
                current['headers']['Referer'] = value.strip()
        elif line.startswith('#'):
            continue
        elif current is not None:
            current['url'] = line
            channels.append(current)
            current = None
    return channels


def _strip_name(text):
    """Remove bullets, emoji flags and markdown from a list label."""
    text = text.split('`')[0]
    text = re.sub(r'^[\s\-\*\+|]+', '', text)
    # drop leading non-letter symbols (emoji flags, globes...)
    while text and not (text[0].isalnum() or text[0] in '(\''):
        text = text[1:]
    return text.strip()


def parse_playlists_md(text):
    """Parse PLAYLISTS.md from iptv-org/iptv.

    Returns a dict:
      categories / languages / regions: [{'name', 'url', 'count'}]
      countries: [{'name', 'code', 'url', 'subdivisions': [
                      {'name', 'code', 'url', 'cities': [{'name','code','url'}]}]}]
    """
    out = {'categories': [], 'languages': [], 'regions': [], 'countries': []}
    country = None
    subdivision = None
    for line in text.splitlines():
        m = _URL_RE.search(line)
        if not m:
            continue
        url, kind, code = m.group(1), m.group(2), m.group(3)
        if line.lstrip().startswith('|'):
            cells = [c.strip() for c in line.strip().strip('|').split('|')]
            name = cells[0] if cells else code
            count = None
            if len(cells) > 1 and cells[1].isdigit():
                count = int(cells[1])
            entry = {'name': name, 'code': code, 'url': url, 'count': count}
        else:
            entry = {'name': _strip_name(line) or code, 'code': code, 'url': url}

        if kind == 'categories':
            if entry.get('count') == 0:
                continue
            out['categories'].append(entry)
        elif kind == 'languages':
            out['languages'].append(entry)
        elif kind == 'regions':
            out['regions'].append(entry)
        elif kind == 'countries':
            entry['subdivisions'] = []
            out['countries'].append(entry)
            country, subdivision = entry, None
        elif kind == 'subdivisions' and country is not None:
            entry['cities'] = []
            country['subdivisions'].append(entry)
            subdivision = entry
        elif kind == 'cities' and subdivision is not None:
            subdivision['cities'].append(entry)
    return out
