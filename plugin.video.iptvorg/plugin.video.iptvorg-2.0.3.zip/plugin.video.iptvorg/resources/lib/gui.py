# -*- coding: utf-8 -*-
"""Netflix-style home window (WindowXML) for IPTV-org."""
import xbmc
import xbmcgui

from resources.lib import common as C
from resources.lib import m3u

# Control ids (must match Home.xml)
NAV_IDS = {101: 'home', 102: 'categories', 103: 'countries',
           104: 'languages', 105: 'sources', 106: 'favourites', 107: 'search'}
LIST_ID = 50

ACTION_PREVIOUS = (9, 10, 92)  # back / escape / nav back


class Home(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.section = 'home'
        self.items = []          # list of dicts: {kind, label, art, data}
        self.index = None
        self._token = 0
        self._play_target = None

    # -- lifecycle ---------------------------------------------------------
    NAV_LABELS = {101: 30040, 102: 30002, 103: 30001, 104: 30003,
                  105: 30020, 106: 30006, 107: 30005}

    def onInit(self):
        # Labels from Python so buttons are never empty regardless of skin.
        for cid, sid in self.NAV_LABELS.items():
            try:
                self.getControl(cid).setLabel(C.T(sid))
            except Exception:
                pass
        try:
            self.getControl(60).setLabel(C.T(30040))
        except Exception:
            pass
        self.setProperty('section', C.T(30040))
        # No busy dialog during onInit: popping a modal dialog while the window
        # is still activating gets the window activation refused. Home is local
        # (no network), so it populates instantly.
        self.show_section('home', busy=False)

    def _set_loading(self, on):
        if on:
            self.setProperty('loading', '1')
        else:
            self.clearProperty('loading')

    # -- data loading (synchronous, on the main GUI thread) ---------------
    def _busy(self, func):
        """Run a blocking call while showing Kodi's busy spinner."""
        dlg = xbmcgui.DialogBusy()
        dlg.create()
        try:
            return func()
        finally:
            dlg.close()

    def show_section(self, section, busy=True):
        self.section = section
        self._token += 1
        token = self._token
        if busy:
            items = self._busy(lambda: self._build_items(section))
        else:
            items = self._build_items(section)
        self.items = items
        self._populate(items, section, token)

    def _build_items(self, section):
        if section == 'home':
            rows = []
            if C.load_favs():
                rows.append({'kind': 'playlist', 'label': C.T(30006),
                             'art': C.media('nav_mylist.png'), 'data': 'favs'})
            for sid, url in C.HOME_ROWS:
                rows.append({'kind': 'section_tile', 'label': C.T(sid),
                             'art': C.media('nav_cat.png'), 'data': url})
            rows.append({'kind': 'playlist', 'label': C.T(30000),
                         'art': C.media('nav_home.png'), 'data': C.INDEX_URL})
            return rows
        if section == 'favourites':
            return [self._chan_item(ch) for ch in C.load_favs()]
        if section == 'sources':
            items = [{'kind': 'add_source', 'label': C.T(30021),
                      'art': C.media('nav_add.png'), 'data': None}]
            for src in C.load_sources():
                items.append({'kind': 'playlist', 'label': src['name'],
                              'art': C.media('nav_mylist.png'), 'data': 'src:' + src['id']})
            return items
        if section == 'search':
            return [{'kind': 'do_search', 'label': C.T(30016),
                     'art': C.media('nav_search.png'), 'data': None}]
        # categories / countries / languages -> tiles that open a playlist grid
        data = self.index_data()
        key = {'categories': 'categories', 'countries': 'countries',
               'languages': 'languages'}[section]
        tiles = []
        for e in data.get(key, []):
            art = C.media('nav_cat.png')
            if section == 'countries' and e['code'] not in ('int', 'undefined'):
                art = C.FLAG_URL.format('gb' if e['code'] == 'uk' else e['code'])
            label = e['name']
            if e.get('count'):
                label = '%s (%d)' % (label, e['count'])
            tiles.append({'kind': 'playlist', 'label': label, 'art': art, 'data': e['url']})
        return tiles

    def index_data(self):
        if self.index is None:
            self.index = C.get_index()
        return self.index

    def _chan_item(self, ch):
        return {'kind': 'channel', 'label': ch['title'],
                'art': ch.get('logo') or C.media('nav_home.png'),
                'data': ch, 'plot': self._plot(ch)}

    @staticmethod
    def _plot(ch):
        parts = []
        if ch.get('group'):
            parts.append(ch['group'].replace(';', ', '))
        if ch.get('tags'):
            parts.append(' '.join(ch['tags']))
        return '\n'.join(parts)

    def _populate(self, items, section, token):
        listitems = []
        for it in items:
            li = xbmcgui.ListItem(label=it['label'])
            art = it['art']
            li.setArt({'thumb': art, 'poster': art, 'icon': art})
            if it.get('plot') and hasattr(li, 'getVideoInfoTag'):
                li.getVideoInfoTag().setPlot(it['plot'])
            listitems.append(li)
        if token != self._token:
            return
        try:
            ctl = self.getControl(LIST_ID)
            ctl.reset()
            if listitems:
                ctl.addItems(listitems)
            title = {'home': 30040, 'categories': 30002, 'countries': 30001,
                     'languages': 30003, 'sources': 30020, 'favourites': 30006,
                     'search': 30005}.get(section, 30040)
            self.setProperty('section', C.T(title))
        except Exception as exc:
            C.log('populate error: %s' % exc, xbmc.LOGERROR)
        self._set_loading(False)
        if listitems:
            self.setFocusId(LIST_ID)

    # -- events ------------------------------------------------------------
    def onAction(self, action):
        if action.getId() in ACTION_PREVIOUS:
            if self.section != 'home':
                self.setFocusId(101)
                self.show_section('home')
            else:
                self.close()

    def onClick(self, controlId):
        if controlId in NAV_IDS:
            self.show_section(NAV_IDS[controlId])
            return
        if controlId == LIST_ID:
            pos = self.getControl(LIST_ID).getSelectedPosition()
            if 0 <= pos < len(self.items):
                self._activate(self.items[pos])

    def _activate(self, it):
        kind = it['kind']
        if kind == 'channel':
            self.play(it['data'])
        elif kind in ('playlist', 'section_tile'):
            self.open_grid(it['data'], it['label'])
        elif kind == 'add_source':
            from resources.lib import plugin
            plugin.add_source()
            self.show_section('sources')
        elif kind == 'do_search':
            self.do_search()

    # -- grid of channels --------------------------------------------------
    def open_grid(self, url, title):
        if url == 'favs':
            channels = C.load_favs()
        else:
            channels = self._busy(lambda: C.load_channels(url))
        if channels is None:
            C.notify(C.T(30014), ms=4000)
            return
        if not channels:
            C.notify(C.T(30015), ms=3000)
            return
        self.items = [self._chan_item(ch) for ch in channels]
        self.section = 'grid'
        self.setProperty('section', title)
        self._populate(self.items, 'grid', self._token)

    def do_search(self):
        query = xbmcgui.Dialog().input(C.T(30016))
        if not query:
            return
        terms = m3u.normalize(query).split()

        def _run():
            channels = C.load_channels(C.INDEX_URL) or []
            return [c for c in channels
                    if all(t in m3u.normalize(c['name'] + ' ' + c.get('group', '')) for t in terms)]
        results = self._busy(_run)
        if not results:
            C.notify(C.T(30015), ms=3000)
            return
        self.items = [self._chan_item(ch) for ch in results]
        self.section = 'grid'
        self.setProperty('section', '%s: %s' % (C.T(30005), query))
        self._populate(self.items, 'grid', self._token)

    # -- playback ----------------------------------------------------------
    def play(self, ch):
        # Close the (opaque) window first so the video is actually visible,
        # then let open_home() start playback full-screen.
        self._play_target = ch
        self.close()


def open_home():
    # NB: the XML filename must NOT be 'Home.xml' — that is Kodi's reserved
    # built-in home window, and Kodi would load the skin's Home instead of ours.
    win = Home('iptvorg-home.xml', C.ADDON_PATH, 'default', '1080i')
    win.doModal()
    target = win._play_target
    del win
    if target:
        xbmc.Player().play(target['url'], C.make_play_item(target))
